## Simple Expression Evaluator

- this is a simple expression evaluator written in c that supports a few arithmetic operations and only accepts expressions written in reverse polish notation.
- it supports the following:
  1. negative numbers
  2. storing result in a variable and print it later
  3. by default stores last printed value in the variable _
